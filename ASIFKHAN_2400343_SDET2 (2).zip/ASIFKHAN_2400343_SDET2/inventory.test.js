import Inventory from "./InventoryClass.js";
import Product from "./ProductClass.js";


describe('Test Inventory',()=>{
    let inventory;

    beforeEach(()=>{
        inventory =new Inventory();
       
    })

    test('Add test',()=>{
        const product=new Product('Pen',10,10);
        inventory.addProductDetails(product);

        const prod=inventory.getAllProducts();
        console.log(prod)

        expect(prod.length).toBe(1);
        expect(prod.name).toBe('Pen');
        expect(prod.price).toBe(10);
        expect(prod.quantity).toBe(10);
    });


    test('Calculate Value',()=>{
        const p1=new Product('Pen',50,2);
        const p2=new Product('Bike toy',200,1);
        inventory.addProductDetails(p1);
        inventory.addProductDetails(p2);

        expect(inventory.getTotalInventory()).toBe(300);
    })

})