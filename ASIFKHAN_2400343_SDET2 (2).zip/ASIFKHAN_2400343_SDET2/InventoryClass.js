import Product from "./ProductClass.js"


class Inventory{
    constructor()
    {
        this.products=[];
    }
    addProductDetails=(product)=>{
        if(!(product instanceof Product)){
            throw new Error('Invalid product type');
        }
        this.products.push(product);
    }

    getAllProducts=()=>this.products;

    getTotalInventory=()=>{
        return this.products.reduce((acc,s)=>acc+s.getTotalValue(),0);
    }
}

export default Inventory;