import Inventory from "./InventoryClass.js";

import Product from "./ProductClass.js";

const product=new Product('Pen',10);
const product1=new Product('Car',10,10);

const inventory=new Inventory();

inventory.addProductDetails(product);
inventory.addProductDetails(product1);

console.log(inventory.getAllProducts())
console.log(inventory.getTotalInventory())