class Product{
    constructor(name, price, quantity) {

        if (typeof name!== 'string' || name.trim() === '') {
            throw new Error("InvalidProductNameError: Product name must be a non-empty string.");
        }

        if(typeof price!== 'number' || price<=0)
        {
            throw new Error("InvalidProductPriceError:Product price must not be a negative number or not to be empty.");
        }

        if(typeof quantity!== 'number' || quantity<=0)
        {
            throw new Error("InvalidProductQuanttityError:Product quantity must not be a negative number or not to be empty.");
        }
        this.name = name.trim();
        this.price = price;
        this.quantity = quantity;
    }

    getTotalValue=()=>this.price*this.quantity;
}

export default Product;
