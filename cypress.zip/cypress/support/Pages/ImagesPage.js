import VideosPage from "./VideosPage";

class ImagesPage
{
    NoOfResultsImages()
    {
        cy.get('[data-attrid="images universal"]').its('length').then(res=>{
            cy.log(`Count of Images for the search ${res}`)
          });
    }
    navigateToVideos()
    {
        cy.get('.YmvwI').contains('Videos').click()
        return new VideosPage();
    }
}
export default ImagesPage