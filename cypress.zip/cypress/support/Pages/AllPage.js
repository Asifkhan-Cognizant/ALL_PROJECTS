import NewsPage from "./NewsPage";

class AllPage
{
    LogAboutResults()
    {
        cy.get('#hdtb-tls').click();
        cy.get('#result-stats').then(res=>{
        cy.log(res.text());
      })
    }

    NoOfResultsAll()
    {
        cy.get('#rso .MjjYud').its('length').then(res=>{
            cy.log(res)
        })    
    }

    navigateToNews()
    {
        cy.get('.YmvwI').contains('News').click();
        return new NewsPage();
    }
}
export default AllPage;