class VideosPage
{
    NoOfResultsVideos()
    {
        
      cy.get('[data-hveid="CBAQAA"]').its('length').then(res=>{
        cy.log(res)
      });
    }
}
export default VideosPage