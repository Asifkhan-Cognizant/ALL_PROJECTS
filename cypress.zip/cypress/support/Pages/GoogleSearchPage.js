import AllPage from "./AllPage";
class GoogleSearchPage
{
    visitSite()
    {
        cy.visit("https://www.google.com/");
    }

    FindNoOfLinks()
    {
        cy.get('a[href]').its('length').then((count) => {
            cy.log(`Number of links in the page: ${count}`);
          });
    }
    displayNameOfLinsks()
    {
        cy.get('a[href]').each(($txt) => {
            cy.log($txt.text());
          });
    }
    TypeSearchText(searchText)
    {
        cy.get('#APjFqb').type(searchText,{ delay: 300 }).click();
        return new AllPage();
    }
    NoOfSearchSuggestions()
    {
        cy.get('.G43f7e > li').its('length').then((res) => {
            cy.log(`Number of search suggestions: ${res}`);
          });
    
          cy.get('#APjFqb').type('{enter}');
    }


}
export default GoogleSearchPage;