import ImagesPage from "./ImagesPage"

class NewsPage
{
    NoOfResultsNews()
    {
        cy.get('.SoaBEf').its('length').then(res=>{
            cy.log(res)
          });
    }
    navigateToImages()
    {
        cy.get('.YmvwI').contains('Images').click()
        return new ImagesPage();
    }
}
export default NewsPage