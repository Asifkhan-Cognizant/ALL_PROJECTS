import  GoogleSearchPage from  "../support/Pages/GoogleSearchPage"


describe('Testing the google', () => {

    const searchPage=new GoogleSearchPage();
    let tdata;
    before(function(){
      cy.fixture('example').then((data)=>{
       tdata = data;
      })
      
    })


    it('Checking the links count and performing a search', () => 
    {
      searchPage.visitSite()
      searchPage.TypeSearchText(tdata.incorrectText);
      searchPage.FindNoOfLinks();
      searchPage.displayNameOfLinsks();
      searchPage.NoOfSearchSuggestions();
      cy.go("back");
      searchPage.TypeSearchText(tdata.halfWord)
      searchPage.NoOfSearchSuggestions();
      cy.go("back");
      const allPage=searchPage.TypeSearchText(tdata.searchText)
      searchPage.NoOfSearchSuggestions();
      cy.pause();
      //AllPage
      allPage.LogAboutResults();
      allPage.NoOfResultsAll();
      cy.viewport(1280, 720)
      cy.screenshot({capture:'fullPage'})
      //News
      const newsPage=allPage.navigateToNews();
      newsPage.NoOfResultsNews();
      cy.screenshot({capture:'fullPage'})
      //Images
      const imagePage=newsPage.navigateToImages();
      imagePage.NoOfResultsImages();   
      cy.screenshot({capture:'fullPage'})
      //videos
      const videoPage=imagePage.navigateToVideos();
      videoPage.NoOfResultsVideos();
      cy.screenshot({capture:'fullPage'})     

      
      Cypress.on("uncaught:exception",(err, runnable) => {
        return false;
      });
    })
})