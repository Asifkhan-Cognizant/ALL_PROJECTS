describe('Window handling test', () => {

    it('Should open new window and visit the URL', () => {
        let val="";
  
      cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
  
    
  
      cy.get('#openwindow').click()

      cy.window().then((win) => {
        cy.stub(win, 'open').callsFake((url) => {
            cy.visit(url);
        }).as('myUrl')
      });
    });

    // Prevents Cypress from failing on uncaught exceptions
  
    Cypress.on('uncaught:exception', (err, runnable) => {
  
      return false;
  
    });
  
  });
   