describe('Handson13',()=>{
    it('task 1',()=>{
        cy.visit('https://www.saucedemo.com/v1/index.html');
        cy.get('[data-test="username"]').type('standard_user');
        cy.get('[data-test="password"]').type('secret_sauce');
        cy.get('#login-button').click()
        cy.get(':nth-child(1) > .pricebar > .btn_primary').click();
        cy.get(':nth-child(2) > .pricebar > .btn_primary').click();
        cy.get('a.fa-layers').click();
        cy.get('.btn_action').contains('CHECKOUT').click();
        cy.get('[data-test="firstName"]').type("Chayan")
        cy.get('[data-test="lastName"]').type("Roy");
        cy.get('[data-test="postalCode"]').type("128799");
        cy.get('.btn_primary').contains("CONTINUE").click();
        cy.get('.btn_action').contains("FINISH").scrollIntoView().click()
        cy.get('.complete-header').invoke('text').should('be.eq','THANK YOU FOR YOUR ORDER')
    })
    it.skip('task 2',()=>{
        cy.visit("https://cleartax.in/s/compound-interest-calculator");
        cy.get('#compoundFrequency').select('yearly')
        cy.get('#principleAmount').clear().type("7000")
        cy.get('#annualrate').clear().type("10")
        cy.get('#periodUnit').select("years")
        cy.get('#periodInDigit').clear().type('1')
        cy.get('.p-12 > :nth-child(1) > :nth-child(1) > .font-bold').invoke('text').should('be.eq','₹ 700')
    })
})
