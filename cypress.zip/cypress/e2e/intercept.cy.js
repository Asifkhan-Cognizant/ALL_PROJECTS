// describe('',()=>{

//     before('',()=>{
//         cy.intercept('POST','https://conduit-api.bondaracademy.com/api/users/login',{fixture : 'example.json'}).as('loginUser')
//     })
//     it('visit side',()=>{
//         cy.visit('https://conduit.bondaracademy.com/');

//         cy.get('.container > .nav > :nth-child(2) > .nav-link').click();

//         cy.get(':nth-child(2) > .form-control').type('asif@gmail.com');

//         cy.get(':nth-child(3) > .form-control').type('12345678');

//         cy.get('form').submit()

//         cy.wait('@loginUser').then(xhr=>{
//             console.log(xhr)
//         })
//     })
// })


describe('Mock Login API Response', () => {
    before(() => {
        cy.intercept('POST', 'https://conduit-api.bondaracademy.com/api/users/login', (req) => {
            req.reply({
                statusCode: 200,
                body: {
                    user: {
                        email: 'mockuser@gmail.com',
                        username: 'AK',
                       "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoyNzQ0Nn0sImlhdCI6MTc0OTEyMjgzNSwiZXhwIjoxNzU0MzA2ODM1fQ.bDKDyBpGYC1BMsrcQ4oBsOJRugA9jE9QtA-59hsxyZU",
                        bio: 'This is a mocked user bio.',
                        image: 'https://example.com/mock-image.jpg'
                    }
                }
            });
        }).as('loginMock');
    });

    it('Verify Mocked Login Response', () => {
        cy.visit('https://conduit.bondaracademy.com/');
        cy.get('.container > .nav > :nth-child(2) > .nav-link').click();
        cy.get(':nth-child(2) > .form-control').type('asif@gmail.com');
        cy.get(':nth-child(3) > .form-control').type('12345678');
        cy.get('form').submit();
    });
});
