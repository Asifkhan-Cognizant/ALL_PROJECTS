/// <reference types="cypress-downloadfile"/>
describe('Practice',()=>{
    beforeEach(()=>
    {
        cy.visit("https://qaboxletstestcypresspracticesite.netlify.app/differentalerttypes");
    })
    it('alert handle',()=>{ 

        cy.get("#alert").click()
        cy.on('window:alert',(txt)=>{
           expect(txt).contains(`I'm an Alert Box`).debug()
        })
    })
    
    it('confirm box',()=>{
        cy.on('window:confirm',(txt)=>{
            expect(txt).contains(`I'm a Confirm Box`);
            return false;
        })
        cy.get("#confirm").click()
    })

    it('prompt',()=>{
        cy.window().then((win)=>{
          let tub=cy.stub(win,'prompt')
          tub.returns("Asifkhan")
          cy.get("#prompt").click()
        })
    })
})


// describe('File Upload',()=>{

//     it('File Upload attach',()=>{
//         cy.visit("https://qaboxletstestcypresspracticesite.netlify.app/fileupload");
//         cy.get("#file-upload1").attachFile({filePath:'newWord.txt',fileName:'worddoc.txt'});
//     })

//     it('drag and drop',()=>{
//         cy.visit("https://qaboxletstestcypresspracticesite.netlify.app/fileupload");
//         cy.get("#holder").attachFile("image.png",{subjectType:'drag-n-drop'});
//     })
//     Cypress.on('uncaught:exception', (err, runnable) => {
//         return false; 
//     });
// })

// describe.only('download file',()=>{
//     it('download file',()=>{
//        cy.downloadFile("https://www.learningcontainer.com/wp-content/uploads/2020/04/sample-text-file.txt","cypress\\fixtures","downloaded.txt");
//        cy.readFile('cypress/fixtures/downloaded.txt',{timeout:60000}).should('contain', 'Lorem ipsum dolor sit amet')
//     })
//})