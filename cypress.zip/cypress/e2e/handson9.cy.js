describe('Chapter 9', ()=>{
    beforeEach(()=>{
        Cypress.on('uncaught:exception', () => false);
    });
 
    it('Visit the GlobusQA frames page,   Navigate to Free Ebooks and print all   the books displayed', ()=>{
        cy.visit('https://www.globalsqa.com/demo-   site/frames-and-windows/#iFrame');
        cy.get('#menu-item-7128').click();
        cy.get('a[rel="noreferrer noopener"]')
        .then((books)=>{
            cy.log(books.text());
        });
    });
 
    it('Visit the GlobusQA frames page,   Navigate to CheatSheets and print SQL   Cheat Sheet content', ()=>{
        cy.visit('https://www.globalsqa.com/demo-   site/frames-and-windows/#iFrame');
        cy.get('#menu-item-6898')
        .click();
        cy.get('a[rel="noreferrer noopener"]')
        .contains('SQL Cheat Sheet')
        .invoke('removeAttr','target')
        .click();
        const res=cy.get('span.has-inline-color, .has-very-dark-gray-color')
        .first()
        .then((text)=>{
            cy.log(text.text());
        });
        cy.go('back');
    });
 
    it('Verify button color in newly opened   browser tab', ()=>{
        cy.visit('https://www.globalsqa.com/demo-   site/frames-and-windows/');
        cy.contains('Click Here')
        .invoke('removeAttr','target')
        .click();
        cy.contains('Click Here')
        .invoke('css','background-color')
        .then((color)=>{
            cy.log(`Button color before hover : ${color}`);
        });
        cy.contains('Click Here')
        .trigger('mouseover');
        cy.contains('Click Here')
        .invoke('css','background-color')
        .then((color)=>{
            cy.log(`Button color after hover : ${color}`);
        });
    });
 
    it('Search Hotels in EaseMyTrip app and print first available hotel AMENITIES', ()=>{
        cy.visit('https://www.easemytrip.com/');
        cy.get('.hotels')
        .click();
        cy.url()
        .should('include','hotels');
        cy.get('.ng-pristine > .hp_inputBox').click();
        cy.get(`[onclick="AddAutoCity('Pune, India')"]`).click();
        cy.get('.search_pnl > .makeFlex > :nth-child(2)').click();
        cy.get(':nth-child(1) > :nth-child(4) > .ui-state-default').click();
        cy.get('#btnSearch').click();
        cy.get('.ng-star-inserted')
        .children()
        .its('length')
        .then((searches)=>{
            cy.log(searches);
        });
    });
});