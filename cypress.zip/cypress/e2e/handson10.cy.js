describe('Chapter 8',()=>{
    beforeEach(()=>{
        Cypress.on('uncaught:exception', () => false);
    });
 
    // it('Test 1',()=>{
    //     cy.visit("https://www.browserstack.com");

    //     cy.get('#signupModalProductButton').
    //     invoke('css', 'background-color').then(bgClr=>{
    //         cy.log(`The Bg colour before mouse hover is :${bgClr}`);
    //     })

    //     cy.get('#signupModalProductButton').trigger('mousedown').wait(200).
    //     then(($btn)=>{
    //         const clr=$btn.css('background-color');
    //         cy.log(clr)
    //     })

    //     cy.get(':nth-child(2) > .col-xs-12 > :nth-child(2) > .btn').click()

    //     cy.get('.best-value-plan[data-content="Best Value"] > .plan-pricing-info > .plan-price-section > .plan-price-details > .amount:visible')
    //         .invoke('text')
    //         .then((res) => {
    //             cy.log(`Visible amount for "Best Value": ${res}`);
    //        });
    // });


    it.skip('File Upload',()=>{
        cy.visit('https://demo.guru99.com/test/upload/');

        cy.get("#uploadfile_0").selectFile("C:\\Users\\2400343\\Downloads\\Image-removebg-preview.png")

        cy.get("#terms").check();

        cy.get("#submitbutton").click();
    })

    it.skip('tooltip task',()=>{
        cy.visit("https://demo.guru99.com/test/tooltip.html")
        cy.get("#download_now").trigger('mouseover');
        cy.get(".tooltip>table>tbody>tr").each(res=>{
            cy.log(res.text())
        })
        
    })


    it.skip('Drag and Drop',()=>{
        cy.visit("https://demo.guru99.com/test/drag_drop.html")

        cy.get(".block14>.button-orange").contains("BANK").trigger("mousedown",{which:1});

        cy.get("#bank>.placeholder").trigger("mousemove").trigger("mouseup",{force:true})
        
        cy.get(".block15>.button-orange").contains("SALES").trigger("mousedown",{which:1});

        cy.get("#shoppingCart3>.ui-widget-content").trigger("mousemove").trigger("mouseup",{force:true});

        cy.get(".block13>.button-orange").contains("5000").trigger("mousedown",{which:1});

        cy.get("#amt7>.placeholder").trigger("mousemove").trigger("mouseup",{force:true})

        cy.get(".block13>.button-orange").contains("5000").trigger("mousedown",{which:1});

        cy.get("#amt8>.placeholder").trigger("mousemove").trigger("mouseup",{force:true})

        cy.get("#t7").should('have.text','5000');
        cy.get("#t8").should('have.text','5000');

    })
    it.skip('copy and paste',()=>
    {
        cy.visit("https://www.tutorialspoint.com/selenium/practice/register.php");

        cy.get("#firstname").type("Selenium")
        cy.get("#lastname").type("Test123456")

        cy.get('#firstname').dblclick().then(()=>{
           cy.get('#firstname').invoke('val').then((firstName) => {
            cy.get('#username').type(firstName);
          });
        })
          cy.get("#lastname").dblclick().then(()=>{
            cy.get("#lastname").invoke('val').then((lastName) => {
                cy.get('#password').type(lastName);
              });
          })
          cy.get('input[type="submit"]').contains("Register").click()
          cy.get('.row>.col-sm-9>.form-control').invoke('val').each(el=>{
            el.should('eq','')
          });  
    });

    it('Read Content from browser windows',()=>{
        cy.visit("https://www.tutorialspoint.com/selenium/practice/browser-windows.php");
        cy.get(`button[title="New Tab"]`).invoke('attr', 'onclick', "window.location.href='new-tab-sample.php'").click()
        cy.log(cy.get('header div>h1'))
        cy.go('back')
        cy.get(`[onclick="PopupCenter('new-window.php','xtf','900','500');"]`).click()
        // cy.get("btn-primary").contains("New Window Message");
    })
})