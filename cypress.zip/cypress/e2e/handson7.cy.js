describe('Chapter 7', ()=>{
  beforeEach(()=>{
      Cypress.on('uncaught:exception', () => false);
  });

  it('Launch the application and switch between pages using Browser Commands', ()=>{
      cy.visit('https://demoqa.com/forms');
      cy.reload();
      cy.url().then((link)=>{
          cy.log(`The current URL is: ${link}`);
      });
      cy.document().then((source)=>{
          cy.log(`Page Source : ${source.documentElement.outerHTML.substring(0, 500)}`);
      });
      cy.title().then((title) => {
          cy.log(`Page Title: ${title}`);
      });
      cy.visit('https://demoqa.com/text-box');
      cy.go('back');
      cy.go('forward');
      cy.visit('https://demoqa.com/forms');
  });

  it('Launch the application and enter the values for textboxes  using WebElement commands', ()=>{
      cy.visit('https://demoqa.com/text-box');
      cy.get('#userName').type('Suriya{enter}');
      cy.get('#userEmail').type('Suriya@gmail.com');
      cy.get('#userName').invoke('val').then((name) => {
          cy.log(`Entered Full Name: ${name}`);
      });
      cy.get('#submit').click();
  });

  it('Launch the application and select the checkboxes using WebElement commands', ()=>{
      cy.visit('https://demoqa.com/checkbox');
      cy.get('.rct-option-expand-all').click();
      cy.contains('span.rct-title', 'Commands')
      .parent()
      .then((checkbox) => {
          if (!checkbox.is(':checked')) {
          cy.wrap(checkbox).click();
          }
      });
      cy.contains('span.rct-title', 'Classified').should('be.visible');
      cy.contains('span.rct-title', 'Classified').parent().click();
      cy.contains('span.rct-title', 'Commands').parent().click();
      cy.contains('span.rct-title', 'Excel File.doc').should('not.be.disabled');
      cy.contains('span.rct-title', 'Excel File.doc').parent().click();
      cy.contains('span.rct-title', 'Notes').parent().click();
  });

  it('Launch the application and select the radio buttons using WebElement commands', ()=>{
      cy.visit('https://demoqa.com/radio-button');
      cy.get('#noRadio')
      .then((radio)=>{
          if(radio.is(':disabled')){
              cy.log(`Radio button disabled`);
          }else{
              cy.log(`Radio button is enabled`);
          }
      });
      //cy.get('#noRadio').should('be.visible');
      cy.get('#yesRadio')
      .then((radio)=>{
          if(radio.is(':checked')){
              cy.log(`Radio button checked`);
          }else{
              cy.get("#yesRadio").check({force:true});
          }
      });
      cy.get('input[type="radio"]').filter(':checked').then(($checkedRadios) => {
          if ($checkedRadios.length > 1) {
            cy.log('More than one radio button is selected!');
          } else {
              cy.log('Only one button is selected.');
          }
      });
  });

  it('Get the tag name, attribute value and CSS Value of the WebElement using WebElement Commands', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.get("#submit").invoke('css','background-color').then((bgcolor)=>{
          cy.log(bgcolor);
      });
      cy.get("#submit").invoke('prop','tagName').then((tag)=>{
          cy.log(tag);
      });
      cy.get("#submit").invoke('attr','class').then((cls)=>{
          cy.log(cls);
      })
  });

  it('    Get the location, size of a web element using WebElement Commands', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.get('#currentAddress')
      .type('No 28, Vadaplani, Chennai');
      cy.get('#currentAddress')
      .then((val)=>{
          const width=val.outerWidth();
          const height=val.outerHeight();
          cy.log(width+" "+height);
      })
      cy.get('#currentAddress')
      .then((val)=>{
          const location=val[0].getBoundingClientRect();
          const x=location.x;
          const y=location.y;
          cy.log(x+" "+y);
      })
  });

  it('Get the list of WebElements using Find Elements command', ()=>{
      cy.visit('https://demoqa.com/selectable');
      cy.get('#verticalListContainer li')
      .each((list)=>{
          cy.log(list.text()+" ");
      });
  });

  it('Select the option in a single select drop down', ()=>{
      cy.visit("https://demoqa.com/automation-practice-form");
      cy.get("#city").should('not.be.disabled');
      cy.get("#state").should('not.be.disabled');
      cy.get("#state").click();
      cy.get('.css-11unzgr').contains("NCR").click();
      cy.get('#city').click();
      cy.get('.css-11unzgr').contains('Delhi').click();
  });

  it('Check if the drop down is a multi select drop down and Select the multiple options in a multi select drop down', ()=>{
      cy.visit("https://demoqa.com/select-menu");
      cy.get("#cars").should('have.attr','multiple');
      cy.get("#cars").select(['Volvo','Opel','Audi']);
      cy.get("#react-select-4-input").should('exist');
      cy.get("#react-select-4-input").click({force:true});
      cy.get("#react-select-4-input").type('Red{enter}');
      cy.get("#react-select-4-input").type('Blue{enter}');
      cy.get("#react-select-4-input").type('Black{enter}');
  });

  it('Select an option from dropdown using  Actions Class', ()=>{
      cy.visit("https://demoqa.com/automation-practice-form");
      cy.get("#city").should('not.be.disabled');
      cy.get("#state").should('not.be.disabled');
      cy.get("#state").click();
      cy.get('.css-11unzgr').contains("NCR").click();
      cy.get('#city').click();
      cy.get('.css-11unzgr').contains('Delhi').click();
  });

  it('Select an option from dropdown using sendKeys', ()=>{
      cy.visit("https://demoqa.com/automation-practice-form");
      cy.get("#city").should('not.be.disabled');
      cy.get("#state").should('not.be.disabled');
      cy.get("#state").click().find('input').type('NCR{enter}');
      cy.get('#city').click().find('input').type('Delhi{enter}');
  });

  it('Select an option from dropdown using JS Executor', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.get('#state').click();
      cy.get('div[id*="react-select-3-option-0"]').click();  
      cy.window().then((win) => win.location.reload());
  });

  it('Should navigate, select state, refresh, and close the browser', () => {
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.get('#state')
      .click()
      .type('NCR{enter}');
      cy.reload();
  });

  it('Pass a data using JS Executor', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.window().then((win) => {
          win.document.getElementById('currentAddress').value = 'No 28, Vadaplani, Chennai';
      });
  });

  it('Generate Alert Pop Window using JS Executor', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.window().then((win) => {
          win.alert('Alert Testing');
      });
      cy.on('window:alert', (text) => {
        expect(text).to.equal('Alert Testing');
      });
  });

  it('Get Inner Text of a Webpage using JS Executor', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.window().then((text) => {
          const innerText=text.document.innerText;
          cy.log(innerText);
      });
  });

  it('Get the Title of a WebPage using JS Executor', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.title().then((title) => {
          cy.log('Page Title:', title);
      });
  });

  it('Scroll the Page using JS Executor', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.window().then((win) => {
          win.scrollBy(0, 500);
      });
  });

  it('Scroll to the bottom and top of the Page using JS Executor', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.window().then((win) => {
          win.scrollTo(0, document.body.scrollHeight);
      });
      cy.wait(2000);
      cy.window().then((win) => {
          win.scrollTo(0, 0);
      });
  });

  it('Scroll to a particular webelement in a Page using JS Executor', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.get('#currentAddress').scrollIntoView().should('be.visible');
  });

  it('Click an element using JS Executor', ()=>{
      cy.visit('https://demoqa.com/automation-practice-form');
      cy.get('#submit').click();
  });

  // it('Draw a Circle within a Canvas using JS Executor', ()=>{
  //     cy.visit('path/to/local/html/file');
  //     cy.get('canvas').then((canvas) => {
  //         const ctx = canvas[0].getContext('2d');
  //         ctx.beginPath();
  //         ctx.arc(100, 100, 50, 0, Math.PI * 2);
  //         ctx.fillStyle = 'blue';
  //         ctx.fill();
  //     });
  // });

  // it('Draw a square and red color within a Canvas using JS Executor', ()=>{
  //     cy.visit('path/to/local/html/file');
  //     cy.get('canvas').then((canvas) => {
  //         const ctx = canvas[0].getContext('2d');
  //         ctx.fillStyle = 'red';
  //         ctx.fillRect(50, 50, 100, 100);
  //     });
  // });

  // it('Draw a line within Canvas using Actions Class', ()=>{
  //     cy.visit('https://sketchtoy.com/');
  //     cy.get('canvas').trigger('mousedown', { x: 50, y: 50 })
  //                     .trigger('mousemove', { x: 200, y: 200 })
  //                     .trigger('mouseup');
  // });
});