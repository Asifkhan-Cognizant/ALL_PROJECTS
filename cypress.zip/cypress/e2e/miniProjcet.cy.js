describe('Testing the google', () => {
    beforeEach('visit this site', () => {
      cy.visit("https://www.google.com/");
    });

    it('Checking the links count and performing a search', () => {
      cy.get('a[href]').its('length').then((count) => {
        cy.log(`Number of links in the page: ${count}`);
      });

      cy.get('a[href]').each(($txt) => {
        cy.log($txt.text());
      });

      cy.get('#APjFqb').type('Cognizant').click();

      cy.get('.G43f7e > li').its('length').then((res) => {
        cy.log(`Number of search suggestions: ${res}`);
      });

      cy.get('#APjFqb').type('{enter}');

      cy.wait(100000);

      cy.get('#hdtb-tls').click();
      cy.get('#result-stats').then(res=>{
        cy.log(res.text());
      })
      
      cy.get('#rso .MjjYud').its('length').then(res=>{
        cy.log(res)
      })

      cy.screenshot({capture:'fullPage'})
      News
      cy.get('.YmvwI').contains('News').click()

      cy.get('.SoaBEf').its('length').then(res=>{
        cy.log(res)
      });
      cy.screenshot({capture:'fullPage'})


      //Images

      cy.get('.YmvwI').contains('Images').click()

      cy.get('[data-attrid="images universal"]').its('length').then(res=>{
        cy.log(`Count of Images for the search ${res}`)
      });
      
      cy.screenshot({capture:'fullPage'})


      //videos
      cy.get('.YmvwI').contains('Videos').click()

      cy.get('[data-hveid="CBAQAA"]').its('length').then(res=>{
        cy.log(res)
      });
      cy.screenshot({capture:'fullPage'})

      Cypress.on("uncaught:exception", (err, runnable) => {
        return false;
      });
   });
  
 })