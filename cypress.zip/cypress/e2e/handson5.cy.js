describe("Chapter 5 Hands On Automation", () => {
  var transactionTime, resultsCount, monthAvg, yearAvg, currentMonth;
 
  it('Google results...', () => {
    cy.visit("https://www.google.com");
    cy.get(".lnXdpd").should('exist');
 
    const startTime = Date.now();
 
    cy.get("#APjFqb").type("cognizant{enter}");
    cy.pause();
    cy.wait(5000);
    cy.get('.srp').should('be.visible').then(() => {
      const endTime = Date.now();
      transactionTime = (endTime - startTime) / 1000;
      cy.log(`Intermediate Search and display time: ${transactionTime} s`);
    });
 
    cy.get(".MjjYud").its('length').then((len) => {
      resultsCount = len;
      cy.log(`Intermediate Search results count: ${resultsCount}`);
    });
 
    Cypress.session.clearAllSavedSessions();
    cy.clearCookies();
    cy.clearLocalStorage();
 
    Cypress.on('uncaught:exception', (err, runnable) => {
      return false;
    });
  });
 
  it("Retrieves TruTime Monthly and Yearly averages from OneCognizant", () => {
    cy.visit("https://onecognizant.cognizant.com/Home");
    cy.contains("OneCognizant").should("be.visible");
 
    cy.get(".searchTopBar").click();
 
    cy.get("#oneCSearchTop").type("TruTime{enter}");
    cy.wait(5000);
    cy.get("#newSearchAppsLST > :nth-child(1)").click();
    cy.wait(5000);
    cy.wait(5000);
    cy.wait(5000);
    cy.get(".monthAvg #A2")
      .should('not.be.empty')
      .invoke("text").then((text) => {
        monthAvg = text.trim();
        cy.log("Monthly Average: " + monthAvg);
      });
 
    cy.get(".yrAvg #A3")
      .should('not.be.empty')
      .invoke("text").then((text) => {
        yearAvg = text.trim();
        cy.log("Yearly Average: " + yearAvg);
      });
 
    cy.get(".month-input-container span")
      .should('not.be.empty')
      .invoke("text").then((text) => {
        currentMonth = text.trim();
        cy.log("Current Month and Year: " + currentMonth);
      });
  });
 
  after(() => {
    cy.log("--- Test Summary ---");
    cy.log("Final Transaction Time (Google Search): " + (transactionTime ? transactionTime + " s" : "Not Captured"));
    cy.log("Final Number of Search Results: " + (resultsCount !== undefined ? resultsCount : "Not Captured"));
    cy.log("TruTime Monthly Average: " + (monthAvg ? monthAvg : "Not Captured"));
    cy.log("TruTime Yearly Average: " + (yearAvg ? yearAvg : "Not Captured"));
    cy.log("TruTime Current Month & Year: " + (currentMonth ? currentMonth : "Not Captured"));
    cy.log("--------------------");
  });
});
